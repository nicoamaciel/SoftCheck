    #include <iostream>
    #include <cstdlib>
    #include <cstring>

    using namespace std;
    #include "persona.h"
    #include "fecha.h"


    //Gets
    string persona::getNombre(){
        return _nombre;
    }
    string persona::getApellido(){
        return _apellido;
    }
    string persona::getMail(){
        return _mail;
    }
    int persona::getDni(){
        return _dni;
    }
    fecha persona::getFechaNacimiento(){
        return _fechaNacimiento;
    }

    //Sets
    void persona::setNombre(string nom){
        _nombre=nom;
    }
    void persona::setApellido(string ape){
        _apellido=ape;
    }
    void persona::setMail(string mail){
        _mail=mail;
    }
    void persona::setDni(int dni){
        _dni=dni;
    }
    void persona::setFechaNacimiento(fecha nacimiento){
        _fechaNacimiento = nacimiento;
    }

    //Comportamiento

    void persona::cargarPersona(){
    string nom, ape, mail;
    int dni;
    fecha fe;

    cout << "Cargar nombre: ";
    cin >> nom;
    cout << "Cargar apellido: ";
    cin >> ape;
    cout << "Cargar mail: ";
    cin >> mail;
    cout << "Cargar dni: ";
    cin >> dni;
    cout << "Carga fecha de naciemiento: ";
    fe.cargarFecha();

    setNombre(nom);
    setApellido(ape);
    setMail(mail);
    setDni(dni);
    setFechaNacimiento(fe);


    }
    void persona::mostraPersona(){

    cout << "Nombre: " << getNombre() << endl;
    cout << "Apellido: " << getApellido() << endl;
    cout << "Mail: " << getMail() << endl;
    cout << "Dni: " << getDni() << endl;
    cout << "Fecha de naciemiento: ";
    _fechaNacimiento.mostrarFecha();

    }

