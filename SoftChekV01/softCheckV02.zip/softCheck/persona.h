#ifndef PERSONA_H_INCLUDED
#define PERSONA_H_INCLUDED

#include "fecha.h"
class persona{

private:
    string _nombre;
    string _apellido;
    string _mail;
    int _dni;
    fecha _fechaNacimiento;
public:

//Gets
    string getNombre();
    string getApellido();
    string getMail();
    int getDni();
    fecha getFechaNacimiento();

//Sets
    void setNombre(string);
    void setApellido(string);
    void setMail(string);
    void setDni(int);
    void setFechaNacimiento(fecha);

//Comportamiento

    void cargarPersona();
    void mostraPersona();



};


#endif // PERSONA_H_INCLUDED
