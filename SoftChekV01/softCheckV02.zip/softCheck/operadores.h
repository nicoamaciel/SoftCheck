#ifndef OPERADORES_H_INCLUDED
#define OPERADORES_H_INCLUDED

#include "persona.h"

class operadores: public persona{

private:
    string _usuario;
    int _turno;
public:
    //Sets
    string getUsuario();
    int getTurno();
    //Gets
    void setUsuario(string);
    void setTurno(int);

    //Comportamientos
    void cargarUsuario();
    void mostrarUsuario();
    int grabarenDisco();
    int leerdeDisco(int);
    void grabarCsv();

};


#endif // OPERADORES_H_INCLUDED
