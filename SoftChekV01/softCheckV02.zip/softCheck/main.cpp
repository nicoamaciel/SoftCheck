#include <iostream>
#include <cstdlib>
#include <cstring>
using namespace std;

#include "equipos.h"
#include "persona.h"
#include "operadores.h"


int main()
{

    int opcion, equipo, impacto, archivoEquipo, operador;
    equipos obj;
    operadores obj2;


    while(true){

    system("cls");
    cout<<"------- SOFTCHECK -------"<<endl;
    cout<<"1.     A/B  EQUIPOS"<<endl;
    cout<<"2.     A/B  IMPACTO"<<endl;
    cout<<"3.     A/B  ALERTAS"<<endl;
    cout<<"4.     A/B  OPERADORES"<<endl;
    cout<<"5.     INFORMES"<<endl;
    cout<<"6.     MANUAL SOFTCHECK"<<endl;
    cout<<"0.     SALIR"<<endl;
    cout<<"-----------------------------"<<endl<<endl;
    cout<<"OPCION: ";
    cin>>opcion;
    system("cls");
    switch(opcion){
    case 1:
        cout<<"1.     ALTA DE EQUIPO"<<endl;
        cout<<"2.     BAJA DE EQUIPO"<<endl;
        cout<<"-----------------------------"<<endl<<endl;
        cout<<"OPCION: ";
        cin>>equipo;
        system("cls");
        switch(equipo){
        case 1:
             obj.cargarEquipos();
             archivoEquipo = obj.grabarenDisco();
             obj.grabarCsv();
             if(archivoEquipo == 1){
                cout << "Equipo cargado en base de datos" << endl;
             }
             else{
                cout << "Error de carga" << endl;
             }


        break;
        case 2:

        break;



        }
    break;
    case 2:
        cout<<"1.     ALTA DE IMPACTO"<<endl;
        cout<<"2.     BAJA DE IMPACTO"<<endl;
        cout<<"-----------------------------"<<endl<<endl;
        cout<<"OPCION: ";
        cin>>impacto;
        system("cls");
        switch(impacto){
        case 1:

        break;



        }
    break;
    case 3:
        cout<<"1.     ALTA DE ALERTA"<<endl;
        cout<<"2.     BAJA DE ALERTA"<<endl;
        cout<<"-----------------------------"<<endl<<endl;

    break;
    case 4:
        cout<<"1.     ALTA DE OPERADORES"<<endl;
        cout<<"2.     BAJA DE OPERADORES"<<endl;
        cout<<"-----------------------------"<<endl<<endl;
        cout<<"OPCION: ";
        cin>>operador;
        system("cls");
        switch(operador){
        case 1:
            obj2.cargarUsuario();
        break;



        }

    break;
    case 5:
        int listado, pos;
        cout<<"1.     LISTADO DE EQUIPOS"<<endl;
        cout<<"2.     EXPORTAR EQUIPOS A CSV"<<endl;
        cout<<"-----------------------------"<<endl<<endl;
        cin>>listado;
        system("cls");
        switch(listado){
        case 1:
            while(obj.leerdeDisco(pos)==1){
                cout << endl;
                obj.mostrarEquipos();
                pos++;
            }


        break;
        case 2:
            while(obj.leerdeDisco(pos)==1){
                cout << endl;
                obj.grabarCsv();
                pos++;
            }

        break;


        }
    break;
    case 0: return 0;
    break;
        }
        system("pause");

    }

	cout<<endl;
	system("pause");





    return 0;
}
