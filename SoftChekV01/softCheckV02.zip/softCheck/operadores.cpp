#include <iostream>

using namespace std;
#include "fecha.h"
#include "persona.h"
#include "operadores.h"

    //Sets
    string operadores::getUsuario(){
        return _usuario;
    }
    int operadores::getTurno(){
        return _turno;
    }
    //Gets
    void operadores::setUsuario(string usu){
        _usuario = usu;
    }
    void operadores::setTurno(int tur){
        _turno = tur;
    }

    //Comportamientos
    void operadores::cargarUsuario(){
        string usu;
        int tur;

        persona::cargarPersona();
        cout << "Cargar usuario: ";
        cin >> usu;
        setUsuario(usu);
        cout << "Cargar turno: ";
        cin >>tur;
        setTurno(tur);
    }
    void operadores::mostrarUsuario(){

    }
